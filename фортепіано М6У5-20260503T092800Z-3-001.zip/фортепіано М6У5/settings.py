from pygame import display

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 400
screen = display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (200, 200, 200)

KEYS = {
    "a": "a6.mp3",
    "b": "b6.mp3",
    "d": "d6.mp3",
    "f": "f6.mp3",
    "g": "g6.mp3",
    "e": "e6.mp3",
    "c": "c6.mp3"
}
